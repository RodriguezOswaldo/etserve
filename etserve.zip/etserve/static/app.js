$(() => {
    $('button').button();
    $('#etv-answer').tabs();
    $('#etv-answer').hide();

    $('#etv-reveal').click(() => {
        $('#etv-answer').show();
    });

    $('#etv-next').click(() => {
        $('#etv-test-nav li').eq(curPos).removeClass('selected');
        curPos = Math.min(curPos + 1, qidSequence.length - 1);
        loadQuestion(qidSequence[curPos]);
        $('#etv-test-nav li').eq(curPos).addClass('selected');
    });

    $('#etv-previous').click(() => {
        $('#etv-test-nav li').eq(curPos).removeClass('selected');
        curPos = Math.max(curPos - 1, 0);
        loadQuestion(qidSequence[curPos]);
        $('#etv-test-nav li').eq(curPos).addClass('selected');
    });

    $('#etv-markright').click(() => {
        $('#etv-test-nav li').eq(curPos).removeClass('wrong').addClass('right');
        testState[qidSequence[curPos]] = ETV_RIGHT;
        updateScoreboard();
    });

    $('#etv-markwrong').click(() => {
        $('#etv-test-nav li').eq(curPos).removeClass('right').addClass('wrong');
        testState[qidSequence[curPos]] = ETV_WRONG;
        updateScoreboard();
    });

    $('#etv-clear').click(() => {
        $('#etv-test-nav li').eq(curPos).removeClass('right').removeClass('wrong');
        testState[qidSequence[curPos]] = ETV_NOTANSWERED;
        updateScoreboard();
    });

    // $('li.etv-test-nav-link').click((evt) => {
    //     console.log($(evt.target).data('qid'));
    // });

    loadTest('az104');
});

const ETV_NOTANSWERED = 0;
const ETV_RIGHT = 1;
const ETV_WRONG = 2;

let testState = {}
let qidSequence = []
let curPos = 0;

function updateScoreboard () {
    let right = 0;
    let wrong = 0;
    for (let qid in testState) {
        if (testState[qid] === ETV_RIGHT) {
            right += 1;
        } else if (testState[qid] === ETV_WRONG) {
            wrong += 1;
        }
    }
    let answered = right + wrong;
    $('#etv-answered').html(`Answered: ${answered}`);
    $('#etv-right').html(`Right: ${right}`);
    $('#etv-wrong').html(`Wrong: ${wrong}`);
    if (answered === 0) {
        $('#etv-percent').html('Percent: -');
    } else {
        $('#etv-percent').html(`Percent: ${(100 * right / answered).toFixed(1)}%`);
    }
}

function loadTest (label) {
    $.get(`/api/test/${label}`, (result) => {
        let n = 1;
        qidSequence = [];
        for (let qid of result) {
            qidSequence.push(qid);
            testState[qid] = ETV_NOTANSWERED;
            let li = $(`<li>${n}</li>`).data('qid', qid).click((evt) => {
                let qid = $(evt.target).data('qid');
                loadQuestion(qid);
            });
            $('#etv-test-nav').append(li);
            n += 1;
        }
        curPos = 0;
        loadQuestion(qidSequence[curPos]);
        updateScoreboard();
    });
}

function loadQuestion (qid) {
    $('#etv-test-nav li').eq(curPos).removeClass('selected');
    $.get(`/api/question/byid/${qid}`, (result) => {
        $('#etv-topic').html(`Topic: ${result.topic}`);
        $('#etv-number').html(`Number: ${result.number}`);
        $('#etv-question-body').html(result.question);
        $('#etv-question-choices').html(result.choices);
        $('#etv-answer-answer').html(result.answer);
        $('#etv-answer-explanation').html(result.explanation);
        if (result.discussion.indexOf('DOCTYPE') === -1) {
            $('#etv-discussion').html(result.discussion);
        } else {
            $('#etv-discussion').html('BADLY FORMED DISCUSSION');
        }
    });
    curPos = qidSequence.indexOf(qid);
    $('#etv-test-nav li').eq(curPos).addClass('selected');
    $('#etv-answer').hide();
}
