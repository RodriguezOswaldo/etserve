# Installation

`npm install`

# Usage

`npm start`

Navigate to http://localhost:4242

# Limitations

* No state is saved. If you reload you get a new test and lose yoru data.
* Only supports AZ-104 right now.
* js and CSS are ugly. I was going for quick and functional, not elegant.
