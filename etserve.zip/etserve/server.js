const express = require('express');
const { Database } = require('sqlite3');

const port = 4242;
const app = express();

const db = new Database('az104.sqlite3');

app.get('/api/question/byid/:qid', async (req, res) => {
    db.get('SELECT * FROM questions WHERE qid=?', Number(req.params.qid), (err, row) => {
        if (err) {
            throw new Error(err);
        }
        res.json(row);
    });
});

app.get('/api/test/:test', async (req, res) => {
    // FIXME: Remove AZ-104 hardcoding
    db.all('SELECT qid, topic FROM questions WHERE label=?', 'az104', (err, rows) => {
        if (err) {
            throw new Error(err);
        }
        let questions = {};
        for (let row of rows) {
            if (row.topic in questions) {
                questions[row.topic].push(row.qid);
            } else {
                questions[row.topic] = [row.qid];
            }
        }
        res.json(buildTest(questions, az104Format));
    });
});

app.use('/', express.static('static'));

db.on('open', (err) => {
    if (err) {
        throw new Error(err);
    }
    console.log('DB open');
   app.listen(port, async () => {
        console.log(`Listening on ${port}`);
   });
});

function buildTest (questions, format) {
    let qids = [];
    // Get questions in each topic
    for (let topic in format.topicCounts) {
        for (let i = 0; i < format.topicCounts[topic]; i++) {
            let j = Math.floor(Math.random() * questions[topic].length);
            qids.push(questions[topic][j]);
            questions[topic].splice(j, 1);
        }
    }
    // Shuffle questions
    for (let i = 0; i < qids.length - 1; i++) {
        let j = i + Math.floor(Math.random() * (qids.length - i));
        let t = qids[i];
        qids[i] = qids[j];
        qids[j] = t;
    }
    // Add case studies
    let caseStudiesTopics = format.caseStudies.topics.slice();
    for (let i = 0; i < format.caseStudies.count; i++) {
        let j = Math.floor(Math.random() * caseStudiesTopics.length);
        qids = qids.concat(questions[caseStudiesTopics[j]]);
        caseStudiesTopics.splice(j, 1);
    }
    return qids;
}

const az104Format = {
    topicCounts: {
        1: 10,
        2: 10,
        3: 10,
        4: 10,
        5: 10,
        6: 5
    },
    caseStudies: {
        count: 2,
        topics: [7, 8, 9, 10, 11, 12, 13, 14]
    }
}

